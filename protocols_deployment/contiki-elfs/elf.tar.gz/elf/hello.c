/* HELLO PROCESS EXAMPLE */
/* ********************* */

#include "contiki.h"

#include <stdio.h> /* For printf() */
/*---------------------------------------------------------------------------*/
PROCESS(hello_process, "Hello world process");
AUTOSTART_PROCESSES(&hello_process);
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(hello_process, ev, data)
{
  PROCESS_BEGIN();
  
  printf("Hello, world\n");

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
