/* ELF LOADER EXAMPLE */
/* ****************** */

#include <contiki.h>
#include "loader/elfloader.h"
#include "cfs/cfs.h"

PROCESS(load_process, "Load Elf Process4");
AUTOSTART_PROCESSES(&load_process);
PROCESS_THREAD(load_process, ev, data){
   int fd;
   int ret;
PROCESS_BEGIN();

   if(elfloader_autostart_processes!=NULL){
      printf("Killing processes\n");
      autostart_exit(elfloader_autostart_processes);
   }
   else{
      printf("No processes to Kill\n");
   }
   fd = cfs_open("hello.ce", CFS_READ | CFS_WRITE);
   ret = elfloader_load(fd);

   printf("Load Return value:%d\n", ret);
   int i;
   for(i=0; elfloader_autostart_processes[i]!=NULL; i++){
      printf("Name of first process[%d]: %s\n", i, elfloader_autostart_processes[i]->name);
   }

   if(ret == ELFLOADER_OK){
      printf("Starting processes...\n");
      autostart_start(elfloader_autostart_processes);
   }
   else{
      printf("Cannot load: %s\n", elfloader_unknown);
   }

   cfs_close(fd);
  

PROCESS_END();
}
